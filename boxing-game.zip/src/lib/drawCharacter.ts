import type { CharacterProfile } from "../types/character";

type Fighter = {
  x: number;
  hp: number;
  maxHp: number;
  punching: number;
  hit: number;
  punchCooldown: number;
  facing: 1 | -1;
  profile: CharacterProfile;
  heroFrameUrl: string | null;
  heroImage: HTMLImageElement | null;
};

const BODY_W = 70, BODY_H = 90, HEAD_R = 42;

export function drawCharacter(ctx: CanvasRenderingContext2D, f: Fighter, groundY: number, label: string) {
  const { profile, heroImage } = f;
  const face = profile.face;
  const skinTone = face.skinTone || "#c68642";
  const shirtColor = profile.appearance.shirtColor || "#333";
  const hairColor = face.hairColor || "#222";
  const hatColor = face.hatColor || "#111";
  const glassesColor = face.glassesColor || "#39ff88";
  const cx = f.x;
  const cy = groundY;
  const flashAlpha = f.hit > 0 ? (f.hit % 2 === 0 ? 0.3 : 1) : 1;

  ctx.save();
  ctx.globalAlpha = flashAlpha;

  // Shadow
  ctx.fillStyle = "rgba(0,0,0,0.3)";
  ctx.beginPath();
  ctx.ellipse(cx, cy + 45, 40, 10, 0, 0, Math.PI * 2);
  ctx.fill();

  // Legs
  ctx.fillStyle = "#222";
  ctx.fillRect(cx - 20, cy, 14, 40);
  ctx.fillRect(cx + 6, cy, 14, 40);

  // Body / shirt
  ctx.fillStyle = shirtColor;
  ctx.beginPath();
  ctx.roundRect(cx - BODY_W / 2, cy - BODY_H, BODY_W, BODY_H, 8);
  ctx.fill();
  ctx.strokeStyle = "rgba(255,255,255,0.2)";
  ctx.lineWidth = 2;
  ctx.stroke();

  // Arms
  const armY = cy - BODY_H + 25;
  const punchExtend = f.punching > 0 ? 40 : 0;

  // Back arm
  ctx.fillStyle = skinTone;
  ctx.fillRect(cx - BODY_W / 2 - 18, armY, 18, 50);

  // Front arm (extends when punching)
  const armX = f.facing === 1 ? cx + BODY_W / 2 : cx - BODY_W / 2 - 18;
  const armExtendX = armX + f.facing * punchExtend;
  ctx.fillStyle = skinTone;
  ctx.fillRect(
    Math.min(armX, armExtendX),
    armY - (punchExtend > 0 ? 10 : 0),
    18 + punchExtend,
    punchExtend > 0 ? 22 : 50
  );

  // Fist glow when punching
  if (punchExtend > 0) {
    ctx.fillStyle = "#ffcc33";
    ctx.beginPath();
    ctx.arc(armExtendX + f.facing * 12, armY - 2, 14, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = "#fff";
    ctx.font = "bold 16px Arial";
    ctx.textAlign = "center";
    ctx.fillText("💥", armExtendX + f.facing * 12, armY + 4);
  }

  // Neck
  ctx.fillStyle = skinTone;
  ctx.fillRect(cx - 10, cy - BODY_H - 15, 20, 20);

  // Head
  const headY = cy - BODY_H - HEAD_R - 15;

  let drewPhoto = false;
  if (heroImage && heroImage.complete && heroImage.naturalWidth > 0) {
    ctx.save();
    ctx.beginPath();
    ctx.arc(cx, headY, HEAD_R, 0, Math.PI * 2);
    ctx.clip();
    try {
      ctx.drawImage(heroImage, cx - HEAD_R, headY - HEAD_R, HEAD_R * 2, HEAD_R * 2);
      drewPhoto = true;
    } catch { /* fallback */ }
    ctx.restore();
    if (drewPhoto) {
      ctx.strokeStyle = f.facing === 1 ? "#18f2b2" : "#ff4f81";
      ctx.lineWidth = 4;
      ctx.beginPath();
      ctx.arc(cx, headY, HEAD_R + 3, 0, Math.PI * 2);
      ctx.stroke();
    }
  }

  if (!drewPhoto) {
    ctx.fillStyle = skinTone;
    ctx.beginPath();
    if (face.faceShape === "round") {
      ctx.arc(cx, headY, HEAD_R, 0, Math.PI * 2);
    } else {
      ctx.ellipse(cx, headY, HEAD_R - 4, HEAD_R + 4, 0, 0, Math.PI * 2);
    }
    ctx.fill();
    ctx.strokeStyle = "rgba(0,0,0,0.2)";
    ctx.lineWidth = 2;
    ctx.stroke();

    // Ears
    ctx.fillStyle = skinTone;
    ctx.beginPath(); ctx.arc(cx - HEAD_R + 2, headY, 8, 0, Math.PI * 2); ctx.fill();
    ctx.beginPath(); ctx.arc(cx + HEAD_R - 2, headY, 8, 0, Math.PI * 2); ctx.fill();

    // Eyes
    ctx.fillStyle = "#fff";
    ctx.beginPath(); ctx.ellipse(cx - 14, headY - 4, 9, 7, 0, 0, Math.PI * 2); ctx.fill();
    ctx.beginPath(); ctx.ellipse(cx + 14, headY - 4, 9, 7, 0, 0, Math.PI * 2); ctx.fill();
    ctx.fillStyle = "#222";
    ctx.beginPath(); ctx.arc(cx - 14 + f.facing * 3, headY - 4, 4, 0, Math.PI * 2); ctx.fill();
    ctx.beginPath(); ctx.arc(cx + 14 + f.facing * 3, headY - 4, 4, 0, Math.PI * 2); ctx.fill();

    // Mouth
    ctx.strokeStyle = "#222";
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.arc(cx, headY + 14, 10, 0.1, Math.PI - 0.1);
    ctx.stroke();

    // Facial hair
    if (face.facialHair && face.facialHair !== "none") {
      ctx.fillStyle = hairColor;
      ctx.globalAlpha = flashAlpha * 0.6;
      ctx.beginPath();
      ctx.ellipse(cx, headY + 18, 22, 14, 0, 0, Math.PI);
      ctx.fill();
      ctx.globalAlpha = flashAlpha;
    }

    // Hair
    if (face.hairStyle !== "bald") {
      ctx.fillStyle = hairColor;
      ctx.beginPath();
      ctx.ellipse(cx, headY - HEAD_R + 8, HEAD_R - 2, 18, 0, Math.PI, 0);
      ctx.fill();
    }
  }

  // Glasses (drawn over photo too)
  if (face.glasses) {
    ctx.strokeStyle = glassesColor;
    ctx.lineWidth = 3;
    if (face.glassesShape === "round") {
      ctx.beginPath(); ctx.arc(cx - 14, headY - 4, 12, 0, Math.PI * 2); ctx.stroke();
      ctx.beginPath(); ctx.arc(cx + 14, headY - 4, 12, 0, Math.PI * 2); ctx.stroke();
    } else {
      ctx.strokeRect(cx - 27, headY - 14, 24, 18);
      ctx.strokeRect(cx + 3, headY - 14, 24, 18);
    }
    ctx.beginPath(); ctx.moveTo(cx - 3, headY - 4); ctx.lineTo(cx + 3, headY - 4); ctx.stroke();
  }

  // Hat
  if (face.hat) {
    ctx.fillStyle = hatColor;
    ctx.beginPath();
    ctx.ellipse(cx, headY - HEAD_R + 4, HEAD_R + 4, 20, 0, Math.PI, 0);
    ctx.fill();
    ctx.fillRect(cx - HEAD_R - 10 + (f.facing === 1 ? 10 : 0), headY - HEAD_R + 2, HEAD_R + 20, 8);
    ctx.fillStyle = "rgba(255,255,255,0.15)";
    ctx.fillRect(cx - 12, headY - HEAD_R - 6, 24, 12);
  }

  // Name label
  ctx.fillStyle = "#fff";
  ctx.font = "bold 16px Arial Black, Arial";
  ctx.textAlign = "center";
  ctx.shadowColor = "rgba(0,0,0,0.8)";
  ctx.shadowBlur = 4;
  ctx.fillText(profile.name, cx, cy + 60);
  ctx.shadowBlur = 0;

  // Controls label
  ctx.fillStyle = "rgba(255,255,255,0.4)";
  ctx.font = "12px Arial";
  ctx.fillText(label, cx, cy + 78);

  ctx.restore();
}

export type { Fighter };
